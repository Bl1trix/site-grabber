import sys,os,re,socket,binascii,time,json,random,threading,Queue,pprint,urlparse,smtplib,telnetlib,os.path,hashlib,string,urllib2,glob,sqlite3,urllib,argparse,marshal,base64,colorama,requests
from colorama import *
from random import choice
from colorama import Fore,Back,init
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from platform import system
from Queue import Queue
from time import strftime
from urlparse import urlparse
from urllib2 import urlopen
colorama.init()

print("""  

  _____       _____                    _  ___      __  ___   ___   ___  
 |  __ \     |  __ \                  | |/ _ \    /_ |/ _ \ / _ \ / _ \ 
 | |  | |_ __| |__) |_ _ _ __ __ _  __| | | | |_  _| | (_) | (_) | (_) |
 | |  | | '__|  ___/ _` | '__/ _` |/ _` | | | \ \/ / |\__, |\__, |\__, |
 | |__| | |  | |  | (_| | | | (_| | (_| | |_| |>  <| |  / /   / /   / / 
 |_____/|_|  |_|   \__,_|_|  \__,_|\__,_|\___//_/\_\_| /_/   /_/   /_/  
                                                                        
 
  Coded by DrParad0x1999
 
 [+] Telegram : @DrParad0x1999
 
 [+] Telegram Channel : https://t.me/DrParad0x1999_Channel
 
 !( make u sure that u put the list in the same folder)!
 
""")


def GrabIPs(site):
	
		site = i.strip()
		try:
			if 'http://' not in site:
				DR9 = socket.gethostbyname(site)
				print "IP: "+DR9
				open('../ips.txt', 'a').write(DR9+'\n')
			elif 'http://' in site:
				url = site.replace('http://', '').replace('https://', '').replace('/', '')
				FK3 = socket.gethostbyname(url)
				print "IP: "+FK3
				open('../ips.txt', 'a').write(FK3+'\n')
	
		except:
			pass
			
nam=raw_input('your Domains list :')
with open(nam) as f:
    for i in f:
        GrabIPs(i)

		
