# Telegram Channel : https://t.me/DrParad0x1999_Channel
lines_seen = set()
with open("../Filtered.txt", "w") as output_file:
	for each_line in open("../listt.txt", "r"):
	    if each_line not in lines_seen: 
	        output_file.write(each_line)
	        lines_seen.add(each_line)
