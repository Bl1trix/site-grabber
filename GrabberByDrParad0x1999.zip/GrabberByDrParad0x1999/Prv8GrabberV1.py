import sys,os,re,socket,binascii,time,json,random,threading,Queue,pprint,urlparse,smtplib,telnetlib,os.path,hashlib,string,urllib2,glob,sqlite3,urllib,argparse,marshal,base64,requests
from colorama import *
from random import choice
from colorama import Fore,Back,init
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from platform import system
from Queue import Queue
from time import strftime
from urlparse import urlparse
from urllib2 import urlopen
init()

def logo():
        clear = "\x1b[0m"
        colors = [36, 32, 34, 35, 31, 37  ]

        x = """
  _____       _____                    _  ___      __  ___   ___   ___  
 |  __ \     |  __ \                  | |/ _ \    /_ |/ _ \ / _ \ / _ \ 
 | |  | |_ __| |__) |_ _ _ __ __ _  __| | | | |_  _| | (_) | (_) | (_) |
 | |  | | '__|  ___/ _` | '__/ _` |/ _` | | | \ \/ / |\__, |\__, |\__, |
 | |__| | |  | |  | (_| | | | (_| | (_| | |_| |>  <| |  / /   / /   / / 
 |_____/|_|  |_|   \__,_|_|  \__,_|\__,_|\___//_/\_\_| /_/   /_/   /_/  
                                                                        
 
  Coded by DrParad0x1999
 
      [+] Telegram : @DrParad0x1999
 
      [+] Telegram Channel : https://t.me/DrParad0x1999_Channel
 
        [1] Mass Zone-h Grabber (From Notifier,Single,Archive & Special Archive ) by Zeerx7 

        [2] Grab IPs From Domain  

        [3] Reverse ip V1 (From IPs to Domains)

        [4] Remove Duplicated Lines

        [5] CMS Filter (Wordpress,Joomla,Drupal,PrestaShop,Opencart...)

        [6] About Script & Check Update
             	  		  
			                  """
        for N, line in enumerate(x.split("\n")):
            sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
            time.sleep(0.02)


logo()


choice=raw_input(' --> ')

if choice=='1':
  print("""
  
    Are u sure ?
    
    if Yes => "y"
    
    else   => "n" \n""")
  t=raw_input('Your Answer ? :')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Files && chmod +x ZonehGrabber.py && python ZonehGrabber.py")
   if system() == 'Windows':
    os.system('cd Files && ZonehGrabber.py && list.txt')
   else:
    print('seriously -_- ?')
  elif t=='n':
   main()
  else :
   print('seriously -_- ?')

elif choice=='2':
  print("""
    Put Your site List in "files" & Result Will Be Get in Folder of Grabber .
  
    u Already do it ?
    
    if Yes => "y"
    
    else   => "n" \n""")
  t=raw_input('Your Answer ? :')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Files && chmod +x GrabIpFromDomain.py && python GrabIpFromDomain.py")
   if system() == 'Windows':
    os.system('cd Files && GrabIpFromDomain.py')
   else:
    print('seriously -_- ?')
  elif t=='n':
   main()
  else :
   print('seriously -_- ?')

elif choice=='3':
  print("""
    Put Your IPs List in "files" & Result Will Be Get in Folder of Grabber .
  
    u Already do it ?
    
    if Yes => "y"
    
    else   => "n" \n""")
  t=raw_input('Your Answer ? :')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Files && chmod +x ReverseIpFirstVersion.py && python ReverseIpFirstVersion.py")
   if system() == 'Windows':
    os.system('cd Files && ReverseIpFirstVersion.py')
   else:
    print('seriously -_- ?')
  elif t=='n':
   main()
  else :
   print('seriously -_- ?') 

elif choice=='4':
  print("""
    Put Your Site List in the Folder of Grabber & Result Will Be Get in the same folder .
    !( Change the name of the list to listt.txt )!
  
    u Already do it ?
    
    if Yes => "y"
    
    else   => "n" \n""")
  t=raw_input('Your Answer ? :')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Files && chmod +x RemoveDuplicateLine.py && python RemoveDuplicateLine.py")
   if system() == 'Windows':
    os.system('cd Files && RemoveDuplicateLine.py')
   else:
    print('seriously -_- ?')
  elif t=='n':
   main()
  else :
   print('seriously -_- ?')

elif choice=='5':
  print("""
    Put Your Site List in the Folder of Grabber & Result Will Be Get in "files/CMS" .
    !( Change the name of the list to sites.txt )!
  
    u Already do it ?
    
    if Yes => "y"
    
    else   => "n" \n""")
  t=raw_input('Your Answer ? :')
  if t=='y':
   if system() == 'Linux':
    os.system("cd Files && chmod +x filter.py && python filter.py ../sites.txt")
   if system() == 'Windows':
    os.system('cd Files && filter.py ../sites.txt')
   else:
    print('seriously -_- ?')
  elif t=='n':
   main()
  else :
   print('seriously -_- ?')

elif choice == '6':
    print("""
    Are u sure of ur choice ?
    
    if Yes => "y"
    
    else   => "n" \n""")
    t = raw_input('Your Answer ? :')
    if t == 'y':
        if system() == 'Linux':
            os.system("cd Files && chmod +x Update.txt && text Update.txt")
        if system() == 'Windows':
            os.system('cd Files && Update.txt')
        else:
            print('seriously -_- ?')
    elif t == 'n':
        main()
    else:
        print('seriously -_- ?')     
   

   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
