Install Python 2.7 & 3.9

Download Link (Python 2.7.14) => https://www.python.org/downloads/release/python-2714/

Download Link (Python 3.9 => https://www.python.org/downloads/release/python-390/

Run => C:\Users\"Username"\AppData\Local\Programs\Python\Python39\Scripts => CMD => install modules
&
Run => C:\Python27\Scripts => CMD => install modules

Modules :

pip install requests
pip install colorama
pip install bs4
pip install tldextract

to Run:

Prv8GrabberV1.py or Python Prv8GrabberV1.py

if u you face any obstacles or issues contact us :

ICQ : DrParad0x1999

Telegram : @DrParad0x1999

Telegram Channel : https://t.me/DrParad0x1999_Channel
